# import the pygame module, so you can use it
#!/usr/bin/env python3
# coding: utf-8
import pygame
import time


# define a main function
def main():

    # initialize the pygame module

    pygame.init()
    # load and set the logo
    #logo = pygame.image.load("logo32x32.png")
    #pygame.display.set_icon(logo)
    pygame.display.set_caption("minimal program")
    global screen,backgroundimage,kanojoimage,textboximage,faceimage,buttonimage,dialoguetext,nametext,dialoguefont
    # create a surface on screen that has the size of 240 x 180
    screen = pygame.display.set_mode((800,600))
    backgroundimage = pygame.image.load("/home/denjo/Desktop/dialogue-demo/GUI/backgrounds/background0.jpg")
    backgroundimage = pygame.transform.scale(backgroundimage,(800,600))
    kanojoimage = pygame.image.load("/home/denjo/Desktop/dialogue-demo/GUI/tachie.png")
    kanojoimage = pygame.transform.scale(kanojoimage,(600,600))
    textboximage = pygame.image.load("/home/denjo/Desktop/dialogue-demo/GUI/textbox.png")
    textboximage = pygame.transform.scale(textboximage,(800,200))
    faceimage = pygame.image.load("/home/denjo/Desktop/dialogue-demo/GUI/faces/face1.png")
    faceimage = pygame.transform.scale(faceimage,(246,246))
    buttonimage = pygame.image.load("/home/denjo/Desktop/dialogue-demo/GUI/button.png").convert()
    buttonimage = pygame.transform.scale(buttonimage,(300,70))
    buttonimage.set_alpha(128)

    pygame.font.init()
    namefont = pygame.font.Font('/home/denjo/Desktop/dialogue-demo/GUI/ipag.ttf',40)
    nametext = namefont.render('彼女',True,(255,255,255))
    dialoguefont = pygame.font.Font('/home/denjo/Desktop/dialogue-demo/GUI/ipag.ttf',30)
    dialoguetext = dialoguefont.render('対話',True,(0,0,0))
    global buttonfont,buttontextlist
    buttonfont = pygame.font.Font('/home/denjo/Desktop/dialogue-demo/GUI/ipag.ttf',30)
    buttontextlist = []



    # define a variable to control the main loop
    global background_pos,kanojo_pos,textbox_pos,face_pos,name_pos,dialogue_pos,button_pos_list,button_text_pos_list
    running = True
    background_pos=(0,0)
    kanojo_pos=(100,0)
    textbox_pos=(0,400)
    face_pos=(280,40)
    name_pos=(80,405)
    dialogue_pos=(80,470)
    button_pos_list=[(50,20),(450,20),(50,120),(450,120),(50,220),(450,220),(50,320),(450,320)]
    button_text_pos_list=[(70,40),(470,40),(70,140),(470,140),(70,240),(470,240),(70,340),(470,340)]

    global last_input
    last_input = None

    i=0
    # main loop
    while running:
        input = get_response("/home/denjo/Desktop/dialogue-demo/response.txt")
        screen.fill((255,255,255))
        update_all(input)
        i+=1

        # event handling, gets all event from the eventqueue
        for event in pygame.event.get():
            # only do something if the event is of type QUIT
            if event.type == pygame.QUIT:
                # change the value to False, to exit the main loop
                running = False


def update_kanojo_face(target_index):
    #print("update face")
    faceimage = pygame.image.load("/home/denjo/Desktop/dialogue-demo/GUI/faces/face" + target_index +".png")
    faceimage = pygame.transform.scale(faceimage,(246,246))
    return faceimage
def update_dialogue_txt(target_str):
    dialoguefont = pygame.font.Font('/home/denjo/Desktop/dialogue-demo/GUI/ipag.ttf',30)
    dialoguetext = dialoguefont.render(target_str,False,(0,0,0))
    return dialoguetext
def update_background(target_index):
    backgroundimage = pygame.image.load("/home/denjo/Desktop/dialogue-demo/GUI/backgrounds/background" + target_index + ".jpg")
    backgroundimage = pygame.transform.scale(backgroundimage,(800,600))
    return backgroundimage
def get_response(path):
    with open(path) as f:
        input = f.readlines()
    input = [x.strip() for x in input]
    return input
def update_button_text_list(str):
    str = str.split('・')
    list = []
    for i in range(len(str)):
        list.append(buttonfont.render(str[i],True,(0,0,0)))
    return list

def check_same_input(input):
    global last_input
    if input == last_input:
        return True
    else:
        return False
def update_all(input):
    global last_input
    # print ("updating")
    # print (input)
    # print (last_input)
    # print("same ?" + str(check_same_input(input)))
    if check_same_input(input):
        return
    last_input = input
    if len(input) == 3:
        backgroundimage = update_background(input[0])
        faceimage = update_kanojo_face(input[1])
        #dialoguetext = update_dialogue_txt(input[2])
        dialogue = input[2]

        screen.blit(backgroundimage,background_pos)
        screen.blit(kanojoimage,kanojo_pos)
        screen.blit(faceimage,face_pos)
        screen.blit(textboximage,textbox_pos)
        screen.blit(nametext,name_pos)
        #screen.blit(dialoguetext,dialogue_pos)
        textx = dialogue_pos[0]
        texty = dialogue_pos[1]
        for c in dialogue:
            char = dialoguefont.render(c,True,(0,0,0))
            if (textx + char.get_rect().w >= 550):
                textx = dialogue_pos[0]
                texty += char.get_rect().h
            screen.blit(char,(textx,texty))
            textx += char.get_rect().w

        pygame.display.flip()
        #time.sleep(3)

    elif len(input) == 4:
        backgroundimage = update_background(input[0])
        faceimage  = update_kanojo_face(input[1])
        #dialoguetext = update_dialogue_txt(input[2])
        dialogue = input[2]
        buttontextlist = update_button_text_list(input[3])

        screen.blit(backgroundimage,background_pos)
        screen.blit(kanojoimage,kanojo_pos)
        screen.blit(faceimage,face_pos)
        screen.blit(textboximage,textbox_pos)
        screen.blit(nametext,name_pos)
        #screen.blit(dialoguetext,dialogue_pos)
        textx = dialogue_pos[0]
        texty = dialogue_pos[1]
        for c in dialogue:
            char = dialoguefont.render(c,True,(0,0,0))
            if (textx + char.get_rect().w >= 750):
                textx = dialogue_pos[0]
                texty += char.get_rect().h
            screen.blit(char,(textx,texty))
            textx += char.get_rect().w

        for i in range(len(buttontextlist)):
            screen.blit(buttonimage,button_pos_list[i])
            screen.blit(buttontextlist[i],button_text_pos_list[i])
        pygame.display.flip()
        #time.sleep(5)

# run the main function only if this module is executed as the main script
# (if you import this as a module then nothing is executed)
if __name__=="__main__":
    # call the main function
    main()
